import java.lang.*;

public class Start {
    public static void main(String[] args) 
	{
        StoryBook book1 = new StoryBook();
        book1 = new StoryBook();
		book2.setIsbn("1597536842");
        book2.setBookTitle("ERWIN KREYSZIG");
        book2.setAuthorName("ADVANCE");
        book2.setPrice(324);
        book2.setCategory("math");
        book2.setAvailableQuantity(500);
        book1.addQuantity(50);
        book1.sellQuantity(30);
        book1.showDetails();

        StoryBook book2 = new StoryBook();
        book2.setIsbn("65845762144");
        book2.setBookTitle("NIL FAMARI");
        book2.setAuthorName("Jane Austen");
        book2.setPrice(360);
        book2.setCategory("book");
        book2.setAvailableQuantity(50);
        book2.addQuantity(90);
        book2.sellQuantity(45);
		
        System.out.println("ISBN"+book2.getIsbn());
		System.out.println("Book Title"+book2.getBookTitle());
		System.out.println("Author Name:"+book2.getAuthorName());
		System.out.println("Price:"+book2.getPrice());
        System.out.println("Category:"+book2.getCategory());
		System.out.println("Available Quantity:"+book2.getAvailableQuantity());

        TextBook book3 = new TextBook();
        book3 = new TextBook("23345345456", "Harper Lee", "Go Set a Watchman", 477, 69, 10);
        book3.addQuantity(70);
        book3.sellQuantity(40);
        book3.showDetails();
        
        TextBook book4 = new TextBook();
        book4.setIsbn("456786495");
        book4.setBookTitle("Wuthering Heights");
        book4.setAuthorName("Emily Bront");
        book4.setPrice(500);
        book4.setAvailableQuantity(50);
        book4.setStandard(38);
        book4.addQuantity(20);
        book4.sellQuantity(45);
        System.out.println("ISBN:"+book4.getIsbn());
		System.out.println("Book Title:"+book4.getBookTitle());
		System.out.println("Author Name:"+book4.getAuthorName());
		System.out.println("Price:"+book4.getPrice());
        System.out.println("Standard;"+book4.getStandard());
		System.out.println("Available Quantity:" + book4.getAvailableQuantity());
    }
}
