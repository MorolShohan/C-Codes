import java.lang.*;
import java.util.*;
public class PositiveNegative
{
public static void main(String[] args)
{
Scanner input = new Scanner(System.in);
int num;
System.out.println("Enter any integer : ");
num = input.nextInt();

if(num>0)
{
System.out.println("Positive");
}
else
{
System.out.println("Negative");
}

}

}