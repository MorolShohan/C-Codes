public class datatype12
{
public static void main(String[] args)
{
	int i;
	boolean b = true;
	char c ='S';
	short s;
	float f =10.5;
	double d;
	

	System.out.println("b = "+b);
	System.out.println("c = "+c);
	System.out.println("f = "+f);

	
}
  
}