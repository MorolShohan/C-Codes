import java.lang.*;

class Student{
    String name = new String();
    int id;
    double cgpa;
    int semesterNo;
    static String universityName = new String();
    Student(){}
    Student(String n, int i, double c, int sn){
        name = n;
        id = i;
        cgpa = c;
        semesterNo = sn;
    }
    void display(){
        System.out.println("Name : "+name);
        System.out.println("Id : "+id);
        System.out.println("Cgpa : "+cgpa);
        System.out.println("Semester No : "+semesterNo);
    }
    public static void main(String[] args){
        Student empty = new Student();
        Student s1 = new Student("Shohan",20440382,3.75,3);
        s1.display();
    }
    
}