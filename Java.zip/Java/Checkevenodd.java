
class Checkevenodd
{
  public static void main(String args[])
  {
    int num=20;
    if ( num % 2 == 0 )
        System.out.println("Entered number is even");
     else
        System.out.println("Entered number is odd");
  }
}