public interface ScientificCalculation {
    double toThePow();
}
