public class gg
{

	
public static void main(String[] args)
{
double d =123.321;
int i =(int)d;
System.out.println("i);
}

}