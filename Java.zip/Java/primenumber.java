import java.lang.*;
import java.util.*;

public class primenumber
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int num,count=0;
		System.out.print("Enter any positive number :");
		num = input.nextInt();
		
		for (int i=2; i<=num; i++)
		{
			if(num%i==0)
			{
				count++;
				break;
			}
			
		}
		
		if(count==0)
		{
			System.out.println("Prime number");
		}
		
		else
			{
				System.out.println("not prime");
				
			}	
		
	}	
}





