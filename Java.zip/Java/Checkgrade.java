import java.util.Scanner;
public class Checkgrade{
public static void main (String[]args)
{
Scanner keyboard = new Scanner(System.in);
System.out.println("Enter a number"):
double s = keyboard.nextDouble();
String n = "Shohan"; 
System.out.println("My name is:"+ n);
System.out.println("My grade is:"+ s);
if( num>=90)
{
System.out.println("My grade is A+");
}
else if( num>=85 && num<=89)
{
System.out.println("My grade is A");
}

else if( num>=80 && num<=84)
{
System.out.println("My grade is B+");
}
else if( num>=75 && num<=79)
{
System.out.println("My grade is B");
}
else if( num>=70 && num<=74)
{
System.out.println("My grade is C+");
}
else if( num>=65 && num<=69)
{
System.out.println("My grade is C");
}
else if( num>=59 && num<=64)
{
System.out.println("My grade is D+");
}
else if( num>=50 && num<=54)
{
System.out.println( "My grade is D");
}
else
{
System.out.println("My grade is F");
}
}
}