public class Human {
    private String type;
    Human()
	{
		
	}
    Human(String type){
        this.type = type;
    }
    public void setType(String type){
        this.type = type;
    }
    public String getType(){
        return type;
    }

}
public class Person extends Human{
    private String name;
    private String gender;
    private int age;
    Person(){}
    Person(String type,String name, String gender, int age){
        super(type);
        this.name = name;
        this.gender = gender;
        this.age = age;
    }

    public void setName(String name){
        this.name = name;
    }
    public void setGender(String gender){
        this.gender = gender;
    }
    public void setAge(int age){
        this.age = age;
    }
    public String getName()
	{return name;
	}
    public String getGender()
	{return gender;
	}
    public int getAge()
	{return age;
	}

}

public class Student extends Person{
    private String studentId;

    Student()
	{
		
	}
    Student(String type, String name, String gender, int age, String studentId){
        super(type,name,gender,age);
        this.studentId = studentId;
    }

    public void setStudentId(String studentId){
        this.studentId = studentId;
    }
    public String getStudentId()
	{return studentId;
	}

    public void Display(){
        System.out.println("Type : "+getType());
        System.out.println("Name : "+getName());
        System.out.println("Gender : "+getGender());
        System.out.println("Age : "+getAge());
        System.out.println("Student id : "+studentId);
    }
}

public class Teacher extends Person {
    private String teacherId;
    private String teacherDesignation;

    Teacher(){}
    Teacher(String type, String name, String gender, int age,String  teacherId, String teacherDesignation){
        super(type,name,gender,age);
        this.teacherId = teacherId;
        this.teacherDesignation = teacherDesignation;
    }

    public void setTeacherId(String teacherId){
        this.teacherId = teacherId;
    }
    public void setTeacherDesignation(String teacherDesignation){
        this.teacherDesignation = teacherDesignation;
    }
    public String getTeacherId()
	{return teacherId;
	}
    public String getTeacherDesignation()
	{return teacherDesignation;
	}

    public void Display(){
        System.out.println("Type : "+getType());
        System.out.println("Name : "+getName());
        System.out.println("Gender : "+getGender());
        System.out.println("Age : "+getAge());
        System.out.println("Teacher id : "+teacherId);
        System.out.println("Teacher Designation : "+teacherDesignation);
    }

}

public class Start {
    public static void main(String[] args) {
        Teacher t5 = new Teacher();
        Teacher t2 = new Teacher("Human","Shohan Morol","Male",21,"20-44038-2","CS proffesor");

        t5.setTeacherId("20440382");
        t5.setTeacherDesignation("ICT teacher");
        t5.setName("SULTAN KHAN");
        t5.setType("IRON MAN");
        t5.setGender("Male");
        t5.setAge(42);
        t2.Display();
        System.out.println();
        t5.Display();
    }
}