import java.lang.*;

public class product
{
	private String productId;
	private String productName;
	private double price;
	int availableQuantity;
	
	public void setproductid(String productId)
	{
		this.productId = productId;
	}
	
	public void getproductId()
	{
		return productId;
	}
	
	public void setproductName(String productName)
	{
		this.productName = productName;
	}
	
	public void getproductName()
	{
		return productName;
	}
	
	public void setprice(double price)
	{
		this.price = price;
	}
	
	public void getprice()
	{
		return price;
	}
	
	public void setAvailableQuantity(int AvailableQuantity)
	{
		this.AvailableQuantity = AvailableQuantity;
	}
	
	public void AvailableQuantity()
	{
		return AvailableQuantity;
	}
	
	public void showdetails();
	
	public static void main(String[] args) 
    {
	product p1 = new product();
	p1.setproductid("asf");
	p1.setproductName("Mouse");
	p1.setprice(204);
	p1.AvailableQuantity("10");
	System.out.println(p1.getproductid());
	System.out.println(p1.get(productName());
	System.out.println(p1.getprice());
	System.out.println(p1.getAvailableQuantity());
	}
	
}