public class Book {
    String isbn;
    String Booktittle;
    String AuthorName;
    double price;
    int AvailableQuantity;

    public Book() {
    }

    public Book(String isbn, String booktittle, String authorName, double price, int availableQuantity) {
        this.isbn = isbn;
        this.Booktittle = booktittle;
        this.AuthorName = authorName;
        this.price = price;
        this.AvailableQuantity = availableQuantity;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getBooktittle() {
        return Booktittle;
    }

    public void setBooktittle(String booktittle) {
        Booktittle = booktittle;
    }

    public String getAuthorName() {
        return AuthorName;
    }

    public void setAuthorName(String authorName) {
        AuthorName = authorName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getAvailableQuantity() {
        return AvailableQuantity;
    }

    public void setAvailableQuantity(int availableQuantity) {
        AvailableQuantity = availableQuantity;
    }

    void Showdetails() {
        System.out.println("Isbn:" + getIsbn());
        System.out.println("Book Title:" + getBooktittle());
        System.out.println("Author Name:" + getAuthorName());
        System.out.println("Price:" + getPrice());
        System.out.println("AvailableQuantity:" + getAvailableQuantity());
    }

}
