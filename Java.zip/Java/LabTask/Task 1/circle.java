import java.lang.*;
public class circle extends Shape
{
	public double radius;
	circle()
	{ 
	}
	circle(double radius)
	{
	this.radius=radius;
	}
	public void setRadius(double radius)
	{
		this.radius=radius;
	}
	public double getRadius()
	{
		return radius;
	}
	public void displayArea()
	{
		System.out.println("Hi there");
	}
}


