import java.lang.*;
public class Triangle extends Shape
{

	private double base;
	private double height;
	Triangle()
	{
	}
	Triangle(double base,double height)
	{
		this.base=base;
		this.height=height;
	}
	public void setHeight(double height)
	{
		this.height=height;
	}
	public void setBase(double base)
	{
		this.base=base;
	}
	public double getHeight()
	{
		return height;
	}
	public double getBase()
	{
		return base;
	}
	public abstract void displayArea()
	{
		System.out.println("Inside Triangle area display");
	}
	
}