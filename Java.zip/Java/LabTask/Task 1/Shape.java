import java.lang.*;
abstract public class Shape
{
	shape()
	{
		
	}
	shape(double dim1, double dim2)
	public void setDim(double dim1)
	{
		this.dim1=dim1;
	}
	
	public double getDim1()
	{
		return dim1;
	}
	abstract void displayArea();
	
}