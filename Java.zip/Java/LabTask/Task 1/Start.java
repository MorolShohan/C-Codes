import java.lang.*;
public class Start
{
	public static void main(String args[])
	{
		Rectangle r1=new Rectangle();
		r1.displayArea();
		
		Triangle t1=new Triangle();
		t1.displayArea();
		
		Circle c1=new Circle();
		c1.displayArea();
		
		Circle c1=new Shape();
		c1.displayArea();
		c1=new Shape();
		c1.displayArea();
		
		
	}
}