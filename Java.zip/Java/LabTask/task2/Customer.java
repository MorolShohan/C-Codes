public class Customer
{
	private int nid;
	private String name;
	FixedAccount fa;
	SavingsAccount sa;
	
	public Customer(){}
	public Customer(int nid,String name,FixedAccount fa,SavingsAccount sa)
	{
		this.nid=nid;
		this.name=name;
		this.fa=fa;
		this.sa=sa;
	}
	
	public void setNid(int nid)
	{
		this.nid=nid;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public void setFixedAccount(FixedAccount fa)
	{
		this.fa=fa;
	}
	public void setSavingsAccount(SavingsAccount sa)
	{
		this.sa=sa;
	}
	public int getNid()
	{
		return nid;
	}
	public String getName()
	{
		return name;
	}
	public FixedAccount getFixedAccount()
	{
		return fa;
	}
	public SavingsAccount getSavingsAccount()
	{
		return sa;
	}
	public void addSavingAccount(SavingsAccount sa)
	{
	this.sa=sa;
	}
	public void remove SavingsAccount(SavingsAccount sa)
	{
	int flag=0;
	for(int i=0;i<<SavingsAccount.length;i++)
	{
	if(SavingsAccount[i]==sa)
	{
	SavingsAccount[i]=null;
	flag=1;
	break;
	}
	
	}
	
	if(flag==0)
	{
	System.out.println("could not be removed");
	}
	else
	{
	System.out.println("removed");
	}
	public void showSavingsAccount()
	{
	System.out.println("account name is :"+getSavingsAccount);
	
	
	public void addFixedAccount(FixedAccount fa)
	{
	this.fa=fa;
	}
	public void remove FixedAccount(FixedAccount fa)
	{
	int flag=0;
	for(int i=0;i<<FixedAccount.length;i++)
	{
	if(FixedAccount[i]==sa)
	{
	FixedAccount[i]=null;
	flag=1;
	break;
	}
	
	}
	
	if(flag==0)
	{
	System.out.println("could not be removed");
	}
	else
	{
	System.out.println("removed");
	}
	public void showFixedAccount()
	{
	System.out.println("account name is :"+getSavingsAccount);
}