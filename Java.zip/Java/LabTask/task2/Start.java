public class Start
{
	public static void main(String args[])
	{
	FixedAccount fa1=new FixedAccount("SHOHAN",522,21);
	SavingsAccount sa1=new SavingsAccount("Morol",45456,4);
	Account a1=new Account("Sultan",305400);
	
	Customer c1=new Customer(1541,"Anmi",fa1,sa1);
	
	System.out.println(c1.getName());
	System.out.println(c1.getNid());
	
	System.out.println(c1.getFixedAccount().getAccountNo());
	System.out.println(c1.getFixedAccount().getBalance());
	System.out.println(c1.getFixedAccount().getTenureYear());
	
	System.out.println(c1.getSavingsAccount().getAccountNo());
	System.out.println(c1.getSavingsAccount().getBalance());
	System.out.println(c1.getSavingsAccount().getInterestRate());
	
	}
}