import java.lang.*;

public class Account {
    private String accountName;
    private String accountNumber;
    private Double balance;
    Account()
	{
	
	}
    Account(String ana,String ano,double ba){}
    void setAccountName(String ana){
        accountName = ana;
    }
    void setAccountNumber(String ano){
        accountNumber = ano;
    }
    void setBalance(double ba){
        balance = ba;
    }
    public String getAccountName(){
        return accountName;
    }
    public String getAccountNumber(){
        return accountNumber;
    }
    public double getBalance(){
        return balance;
    }

public class FixedAccount extends Account {
    private double interestRate;
    private int year;
    FixedAccount()
	{
	
	}
    FixedAccount(double ir){
        interestRate = ir;
    }
    public void setInterestRate(double ir){
        interestRate = ir;
    }
    public double getInterestRate(){
        return interestRate;
    }
    public void setYear(int y){
        year = y;
    }
    public int getYear()
	{
        return year;
    }
    public double calculateInterestAmount()
	{
        return getBalance()*year*interestRate;
    }
}

public class Start {
    public static void main(String[] args) {
        FixedAccount empty = new FixedAccount();
        FixedAccount obj = new FixedAccount(2.5);

        obj.setAccountName("Shohan Morol");
        obj.setAccountNumber("20-44038-2");
        obj.setBalance(53500.25);
        obj.setYear(2010);
         
		 
        System.out.println("Account name             : "+ obj.getAccountName());
        System.out.println("Account Number is        : "+ obj.getAccountNumber());
        System.out.println("Balance is               : "+ obj.getBalance() + " Taka");
        System.out.println("Interest Rate            : "+ obj.getInterestRate() + "%");
        System.out.println("Year is                  : "+ obj.getYear());
        System.out.println("Total Interest amount is : "+ obj.calculateInterestAmount());
	}

}