import java.utill.scanner;
public class inputdemo
{
public static void main(String[] args)
{
	scanner input = new scanner(System.in);
	int number;
	
	System.out.println("Enter any number : ");
	number = input.nextInt();
	
	System.out.println("Number = "+number);
}

}