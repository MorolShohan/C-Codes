public class student
{
private int studentid;
private String studentName;

public student()
{

}

public student(int sid, String sname)
{
studentid = x;
studentName = y;
}
public void print()
{
System.out.println("Name is :"+studentName);
system.out.println("Id is :"+studentid);
}

public static void main(String[] args)
{
student s3= new student(2044038,"Shohan");
s3.print();
}

}