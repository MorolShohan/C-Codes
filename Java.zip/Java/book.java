import java.lang.*;
public class Book
{
	private String isbn;
	private String bookTitle;
	private String authorname;
	private double price;
	private int availableQuantity;
	
	Book()
	{
		System.out.println("Empty constructor");
	}
	
	Book(String isbn, String bookTitle, String authorName, double price, int availableQuantity)
	{
		this.isbn = isbn;
		this.bookTitle = bookTitle;
		this.authorName = authorName;
		this.price = price;
		this.availableQuantity = availableQuantity;
	}
	
	public void setIsbn(String isbn)
	{
		this.isbn = isbn;
	}
	
	public String getIsbn()
	{
		return isbn;
	}
	
	public void setBookTitle(String bookTitle)
	{
		this.bookTitle = bookTitle;
	}
	
	public String getBookTitle()
	{
		return bookTitle;
	}
	
	public void setAuthorName(String authorName)
	{
		this.authorName = authorName;
	}
	
	public String getauthorName()
	{
		return authorName;
	}
	
	public void setPrice(double price)
	{
		this. price = price;
	}
	
	public double getprice()
	{
		return price;
	}
	
	public void setAvaiableQuantity(int availableQuantity)
	{
		this.availableQuantity = availableQuantity;
	}

	public int getavailableQuantity()
	{
		return availableQuantity;
	}
	
	public void addQuantity(int amount)
	{
		System.out.println("Amount is : "+amount);
	}
	
	public void sellQuantity(int amount)
	{
		System.out.println("Amount is : "+amount);
	}
	
	public void showDetails()
	{
		System.out.println("isbn is :"+getIsbn());
		System.out.println("bookTitle is :"+getBookTitle());
		System.out.println("authorName is :"+getauthorName());
		System.out.println("price is :"+getprice());
		System.out.println("availableQuantity is :"+getavailableQuantity());
	}
	
}

public class StoryBook extends Book
{
	private String catagory;
	
	StoryBook()
	{
	}
	
	StoryBook(String catagory)
	{
		this.catagory = catagory;
	}
	
	public void setCategory(String category)
	{
		this.category =category;
	}
	
	public String getCategory()
	{
		return catagory;
	}
	
	public class TextBook extends Book
	{
		
		int standard;
		
		TextBook()
		{
		}
		
		TextBook(int standard)
		{
			this.standard = standard;
		}
		
		public void setStandard(int standard)
		{
			this.standard = standard;
		}
		
		public int getStandard()
		{
			return standard;
		}
		
	}
	
	public class start
	{
		public static void main(String args[])
		{
			StoryBook s1 = new StoryBook("Romance");
			s1.setIsbn("546525");
			s1.setBookTitle("oporajita");
			s1.setAuthorName("Humayon ahmed");
			s1.setprice(500);
			s1.setAvaiableQuantity(20);
			s1.showDetails();
			StoryBook s2 = new StoryBook("Thrillar");
			s2.setIsbn("5465df25");
			s2.setBookTitle("oporajita nodi");
			s2.setAuthorName("ayman sadik");
			s2.setprice(250);
			s2.setAvaiableQuantity(100);
			s2.showDetails();
			TextBook t1 = new TextBook("12");
			t1.setIsbn("5465525");
			t1.setBookTitle("religiomn");
			t1.setAuthorName("taheri");
			t1.setprice(100);
			t1.setAvaiableQuantity(5000);
			t1.showDetails();
			Textbook t2 = new TextBook("15");
			t2.setIsbn("5465dfDFSD25");
			t2.setBookTitle("science");
			t2.setAuthorName("ayman sadik prodhan");
			t2.setprice(350);
			t2.setAvaiableQuantity(600);
			t2.showDetails();
		}
		
	}
	
	
}


			
	




	


	
	
	
	


	
	

	
	
