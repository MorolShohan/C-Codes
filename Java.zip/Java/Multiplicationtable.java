import java.lang.*;
import java.util.*;
public class Multiplicationtable
{
public static void main(String[] args)
{
	Scanner input = new Scanner(System.in);
	int n,mul=1;
	
	System.out.print("Enter the number :");
	n = input.nextInt();
	
	for(int i =1; i<=10; i++)
	{
		System.out.println(n+"X"+i+ "=" +n*i);
	}
}

}

