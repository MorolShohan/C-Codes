import java.lang.*;
public class Car
{
    String modelName;
    int modelYear;
    String CarType;
    Car()
    {
        System.out.println("Empty Parametar");
    }
    Car(String mn,int my,String ct)
    {
        modelName=mn;
        modelYear=my;
        CarType=ct;
    }
    void SetModelName(String mn)
    {
        modelName=mn;
    }
    void setModelYear(int my)
    {
        modelYear=my;
    }
    void setCarType(String ct)
    {
        CarType=ct;
    }
    String getModelName()
    {
        return modelName;
    }
    int getModelYear()
    {
        return modelYear;
    }
    String getCarType()
    {
        return CarType;
    }
   
}

class Start
{
public static void main(String args[])
    {
        Car c1= new Car();
        Car c2= new Car("MARCEDES",2009,"256452");
        System.out.println("Model Name: "+c2.getModelName());
        System.out.println("Model Year: "+c2.getModelYear());
        System.out.println("Car Type: "+c2.getCarType());
    }
}