public class Assigndemo
{
	
	public static void main(String[] args)
	{
		int x = 3;
		int y = 2;
		
		x+=y; //x =x+y
		System.out.println("x = "+x);
		
		x-=y; //x =x-y
		System.out.println("x = "+x);
		
		x*=y; //x =x*y
		System.out.println("x = "+x);
		
		x/=y; //x =x/y
		System.out.println("x = "+x);
		
		x%=y; //x =x%y
		System.out.println("x = "+x);
	}
	
}