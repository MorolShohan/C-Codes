public class typecasting
{
public static void main(String[] args)
{
int firstNum=7806;
int firstNum=0786;

int sum = firstNum+firstNum;
System.out.print("Sum is : "+sum);
}

}