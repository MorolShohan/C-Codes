import java.lang.*;
public class Customer
{
	private String custName;
	private String custNid;
	
	public Customer()
	{
	}
	
	public Customer(String custName, String custNid)
	{
		this.custName = custName;
		this.custNid = custNid;
	}
	
	public void setCustName(String custName)
	{
		this custName = custName;
	}
	
	public void setCustNid (String custNid)
	{
		this.custNid = custNid;
	}
	public Sring getCustName()
	{
		return custName;
	}
	public String getCustNid()
	{
		return custNid;
	}
	
	public void showDetails()
	{
		System.out.println("customer Name is: "+custName);
		System.out.println(" Customer id is : "+custNid);

	}
	
public class Shop
{
	private String shopName;
	String city;
	Customer customer;
    public Shop()
	{
	}
	public Shop(String shopName, String city)
	{
		this.shopName = shopName;
		this.city = city;
	}
	public void setShopName(String shopName)
	{
		this.shopName = shopName;
	}
	
	public void setCity(String city)
	{
		this.city =city;
	}
	
	public void setCustomer(Customer customer)
	{
		this.customer = customer;
	}
	
	public Customer getCustomer()
	{
		return customer;
	}
	
	public String getShopname()
	{
		return shopName;
	}
	
	public String getcity()
	{
		return city;
	}
	public void showDetails()
	{
		System.out.println(" Shop Name is : "+shopName);
		System.out.println("City is : "+city);
		System.out.println("Cgpa is : "+cgpa);
		customer.showDetails();
				
	}
	
public class Start
{
	public static void main(String args[])
	{
		Shop s1 = new Shop("kampala general store","Kampala");
		Customer c1 = new Customer("Shohan","20440382");
		s1.setCustomer(c1);
		s1.showDetails();
		c1.showDetails();
		
	}
	
}



	
	