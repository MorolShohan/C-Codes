import java.lang.*;

public class array
{
	public static void main(String[] args)
	
{
	int[] num = new int[8];
	
	num[0] = 10;
	num[1] = 20;
	num[2] = 30;
	num[3] = 40;
	num[4] = 50;
	num[5] = 60;
	num[6] = 70;
	num[7] = 80;
	
	int sum = num[0] +num[1] +num[2] +num[3] +num[4] +num[5]+ num[6] +num[7];
	
	System.out.println("SUM = "+sum);
	
	int len = number.length;
	System.out.println("Array size = "+len);
}

}