public class TextBook extends Book {
    int Standard;

    public TextBook(int standard) {
        Standard = standard;
    }

    public TextBook(String isbn, String booktittle, String authorName, double price, int availableQuantity,
            int standard) {
        super(isbn, booktittle, authorName, price, availableQuantity);
        this.Standard = standard;
    }

    public TextBook() {
	}

	public int getStandard() {
        return Standard;
    }

    public void setStandard(int standard) {
        Standard = standard;
    }

}
