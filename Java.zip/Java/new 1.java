public class Account
{
private String accountname;
private double balance;
public Account(){}
public Account(String aname,double b)
{
	accountname=aname;
	balance=b;
}
public void deposit(double am)
{
	balance=am+balance;
}
public void withdraw(double am)
{
	balance=am-balance;
}
void display()
{
	System.out.println("AccountName:"+accountname);
	System.out.println("Accountbalance:"+balance);
}
public static void main(String args[])
{Account a1= new Account("Anik kumar dash", 300.0);
 a1.display();
}
}
