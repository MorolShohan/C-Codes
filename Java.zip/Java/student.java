public class student
{
private int studentid;
private String studentName;

public student()
{

}

public student(int sid, String sname)
{
studentid = sid;
studentName = sname;
}
public void print()
{
System.out.println("Name is :"+studentName);
system.out.println("Id is :"+studentid);
}

public static void main(String[] args)
{
student s1= new student(2044038,"Shohan");
s1.print();
}

}