import java.lang.*;
import java.util.*;

public class vowelconsonant
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		char chl;
		System.out.print("Enter any letter : ");
		ch1 = input.next().charAt(0);
		
		if (ch1=='a' || ch1=='e' || ch1=='i' || ch1=='o' || ch1=='u')
		{
			system.out.println("Vowel");
		}
		else
		{
					system.out.println("Consonant");
		}
		
	}
	
}


