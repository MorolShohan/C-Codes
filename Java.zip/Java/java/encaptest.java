import java.lang.*;
public class encaptest
{
public static void main(String[] args)
{
	shohan s1 = new shohan();
	s1.setName("Shohan");
	s1.getRoll(101);
	s1.display();
}

}

