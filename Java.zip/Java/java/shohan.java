import java.lang.*;
public class shohan
{
	private int roll;
	private String name;
	
	shohan()
	{
		System.out.println("Inside empty constructor");
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	
	public void setRoll(int roll)
	{
		this.roll= roll;
	}
	public int getRoll()
	{
		return roll;
	}
	
	public void display()
	{
	System.out.println("Name is : "+name);
	System.out.println("Roll is : "+roll);
	}
	
	
}