import java.lang.*
public class Unarydemo

{
public static void main(String [] args)
{
	int x = 10;
	int result;
	
	result = +x;
	System.out.println("result = "+result);
	
	result = -x;
	System.out.println("result = "+result);
}

}