import java.utill.scanner;
public class Arithmeticdemo
{
	public static void main(String[] args)
	{
		scanner input = new scanner(system.in);
		int num1,num2,result;
		
		System.out.println("Enter first number : ");
		num1 = input.nextint();
		
		System.out.println("Enter second number : ");
		num2 = input.nextint();
		
		result = num1 + num2;
		system.out.println("Sum = "+result);
		
		result = num1 - num2;
		system.out.println("Sub = "+result);
		
		result = num1 * num2;
		system.out.println("multiplication = "+result);
		
		result = (double) num1 / num2;
		system.out.println("div = "+result);
		
		result = num1 % num2;
		system.out.println("mod = "+result);
	}
	
}