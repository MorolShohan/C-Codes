public class Calculator
{
	double num1;
	double num2;
	
	Calculator()
	{
		System.out.println("This is a default constractor");
	}
	
	Calculator(double n1,double n2)
	{
		num1 = n1;
		num2 = n2;
	}
	
	double add(double n1,double n2)
	{
		return n1+n2;
	}
	
	double sub(double n1,double n2)
	{
		if(n1>n2)
		{
			return n1-n2;
		}
		else
		{
			return n2-n1;
		}
	}
	
	double div(double n1,double n2)
	{
		return n1/n2;
	}
	
	double mult(double n1,double n2)
	{
		return n1*n2;
	}
	
	void display()
	{
		System.out.println("The value of number1 is :"+num1);
		System.out.println("The value of number2 is :"+num2);
	}
	
	public static void main(String args[])
	{
		Calculator c1 = new Calculator(10.5,15.5);
		c1.display();
		System.out.println("The summision is      : "+c1.add(10.5,15.5));
		System.out.println("The subtraction is    : "+c1.sub(10.5,15.5));
		System.out.println("The division is       : "+c1.div(10.5,15.5));
		System.out.println("The multiplication is : "+c1.mult(10.5,15.5));
		
	}
	
}