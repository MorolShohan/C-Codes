import java.lang.*;
import java.util.*;
public class loop1demo
{
	public static void main(String[] args)
	{
		
		Scanner input = new Scanner(System.in);
		int sum = 0;
		int m,n;
		System.out.print("Enter any number :");
		m = input.nextInt();
		
		System.out.println("Enter any number :");
		n = input.nextInt();
		
		for(int i=m; i<= n;i++)
		{
			if(i%2==0)
			sum = sum+i;
		}
		System.out.println("Sum equals : "+sum);
	}
	
}

