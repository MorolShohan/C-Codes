import java.lang.*;

public class math
{

public static void main(String[] args)
{

int x = 5;
int y = 10;

System.out.println(Math.max(x,y));	
}

}

