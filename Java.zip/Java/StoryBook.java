public class StoryBook extends Book {
    String category;

    public StoryBook() {

    }

    public StoryBook(String category) {
        this.category = category;
    }

    public StoryBook(String isbn, String booktittle, String authorName, double price, int availableQuantity,
            String category) {
        super(isbn, booktittle, authorName, price, availableQuantity);
        this.category = category;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    

}
