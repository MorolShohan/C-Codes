import java.lang.*;

public class Account
{
	private String accountName;
	private String accountNumber;
	private double balance;
	
	Account()
	{
	}
	
	Account(String ana,String ano,double ba)
	{
		accountName =ana;
		accountNumber =ano;
		balance =ba;
	}
	
	public void setaccountName(String ana)
	{
		setaccountName=ana;
	}
	public void setaccountNumber(String ano)
	{
		accountNumber=ano;
	}
	public void setbalance(double ba)
	{
		balance=ba;
	}
	public String getaccountName()
	{
		return accountName;
	}
	public String getaccountNumber()
	{
		return accountNumber;
	}
	public double getbalance()
	{
		return balance;
	}
	
}

class FixedAccount extends Account
{
	private double interestRate;
	private int year;
	FixedAccount()
	{
	}
	
	FixedAccount(double ir)
	{
		interestRate = ir;
	}
	
	public void setinterestRate(double ir, int y )
	{
		interestRate = ir;
		Year =y;
	}
	public void setYear(int y)
	{
		Year= y;
	}
	public double getInterestRate()
	{
		return interestRate;
	}
	public int getYear()
	{
		return Year;
	}
	public double calculateInterestAmount()
	{
		double amount;
		double balance=50000.21;
		int year=2010;
		double interestRate=15.6%;
		
		amount = balance*year*interestRate;
		System.out.println("Total interest amount is : "+amount);
	}
	
	}
	
	class game
	{
		public static void main(String[] args)
		{
			FixedAccount f1 = new FixedAccount(15.6%,2010);
			f1.setaccountName("Shohan");
			f1.setaccountNumber("2044");
			f1.setbalance(50000.21);
			System.out.println("Account name : "+f1.getaccountName);
			System.out.println("Account number is : "+f1.getaccountNumber);
			System.out.println("Balance is : "+f1.getbalance);
			System.out.println("InterestRate is : "+f1.getInterestRate);
			System.out.println("Year is : "+f1.year);
			f1.calculateInterestAmount();
		}
		
	}
	
