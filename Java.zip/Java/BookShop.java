public class BookShop {
    String name;
    Book books[]=new Book[100];
    public BookShop(String name) {
        this.name = name;
    }
    public BookShop() {
    }
    public void insert(Book b){
        int flag=0;
        for(int i=0;i<books.length;i++){
            if(books[i]==null){
                books[i]=b;
                flag=1;
                break;
            }
        }
        if(flag == 1){System.out.println("----Inserted----");}
		else {System.out.println("----CanNot Insert----");}
    }
    public void remove(Book b){
        int flag = 0;
		for(int i=0; i<books.length; i++)
		{
			if(books[i] == b)
			{
				books[i] = null;
				flag = 1;
				break;
			}
		}
		if(flag == 1){System.out.println("----Removed----");}
		else {System.out.println("----CanNot Remove----");}

    }
    public void showAlls()
	{
		for(int i=0; i<books.length; i++)
		{
			if(books[i] != null)
			{
				System.out.println("--------------");
				System.out.println("AuthorName: "+books[i].getAuthorName());
				System.out.println("Available Quantity: "+books[i].getAvailableQuantity());
				System.out.println("Book Title: "+books[i].getBooktittle());
                System.out.println("Isbn:"+books[i].getIsbn());
                System.out.print("Price:"+books[i].getPrice());
				System.out.println();
			}
		}
	}
    
}
