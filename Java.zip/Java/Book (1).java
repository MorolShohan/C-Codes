import java.lang.*;
public class Book
{
	private String isbn;
	private String bookTitle;
	private String authorname;
	private double price;
	private int availableQuantity;
	
	Book()
	{
		System.out.println("Empty constructor");
	}
	
	Book(String isbn, String bookTitle, String authorName, double price, int availableQuantity)
	{
		this.isbn = isbn;
		this.bookTitle = bookTitle;
		this.authorName = authorName;
		this.price = price;
		this.availableQuantity = availableQuantity;
	}
	
	public void setIsbn(String isbn)
	{
		this.isbn = isbn;
	}
	
	public String getIsbn()
	{
		return isbn;
	}
	
	public void setBookTitle(String bookTitle)
	{
		this.bookTitle = bookTitle;
	}
	
	public String getBookTitle()
	{
		return bookTitle;
	}
	
	public void setAuthorName(String authorName)
	{
		this.authorName = authorName;
	}
	
	public String getauthorName()
	{
		return authorName;
	}
	
	public void setPrice(double price)
	{
		this. price = price;
	}
	
	public double getprice()
	{
		return price;
	}
	
	public void setAvaiableQuantity(int availableQuantity)
	{
		this.availableQuantity = availableQuantity;
	}

	public int getavailableQuantity()
	{
		return availableQuantity;
	}
	
	public void addQuantity(int amount)
	{
		System.out.println("Amount is : "+amount);
	}
	
	public void sellQuantity(int amount)
	{
		System.out.println("Amount is : "+amount);
	}
	
	public void showDetails()
	{
		System.out.println("isbn is :"+getIsbn());
		System.out.println("bookTitle is :"+getBookTitle());
		System.out.println("authorName is :"+getauthorName());
		System.out.println("price is :"+getprice());
		System.out.println("availableQuantity is :"+getavailableQuantity());
	}
	
}

public class StoryBook extends Book
{
	private String catagory;
	
	StoryBook()
	{
	}
	
	StoryBook(String catagory)
	{
		this.catagory = catagory;
	}
	
	public void setCategory(String category)
	{
		this.category =category;
	}
	
	public String getCategory()
	{
		return catagory;
	}
	
	public class TextBook extends Book
	{
		
		int standard;
		
		TextBook()
		{
		}
		
		TextBook(int standard)
		{
			this.standard = standard;
		}
		
		public void setStandard(int standard)
		{
			this.standard = standard;
		}
		
		public int getStandard()
		{
			return standard;
		}
		
	}
	
	public class BookShop
	{
		private String name;
		Book books[];
		
		public BookShop()
		{
		}
		
		public BookShop(String name)
		{
			this.name = name;
		}
		
		public void setName(String name)
	{
		this.name=name;
	}
	
	public String getName()
	{
		for(int i=0;i<books.length;i++)
		{
			if(books[i]!=null)
			{
				System.out.println("Book name is :"+books[i].getName());
				System.out.println("Book Title is :"+books[i].getBookTitle());
			}
			
		}
		
	}
	
	public void searchBook(String isbn)
	{
		int flag=0;
		for(int i=0;i<books.length;i++)
		{
			if(books[!]!=null)
			{
				if(books[i].getIsbn().equals(isbn))
				{
					flag=1;
				}
				
			}
			
		}
		
		if(flag==0)
		{
			System.out.println("The course does not exist");
		}
		else
		{
			System.out.println("The course exist");
		}
	}
	public boolean removeBook(Book b)
	{
		int flag=0;
		for(int i=0;i<<books.length;i++)
		{
			if(books[i]==b)
			{
				books[i]=null;
				flag=1;
				break;
			}
			
		}
		
		if(flag==0)
		{
			System.out.println("Course could not be removed");
		}
		else
		{
			System.out.println("Course removed");
		}
		
			
	
public boolean SetBook(Book b)
{
	books=b;
}
public boolean insertBook(Book b)
{
int flag=0;
for(int i=0;i<books.length;i++)
{
if books[i]==null)
{
	books[i]=b;
	flag=1;
	break;
}

}

if(flag==0)
{
	System.out.println("Course could not be inserted");
}
else
{
	System.out.println("Course inserted");
}

public void showAllBooks()
{
	System.out.println("Book name is"+books[i].getName);
}

public class start
{
	public static void main(String[] args)
	{
		BookShop b1 = new BookShop();
		TextBook t1 = new TextBook("101");
		TextBook t2 = new TextBook("102");
		TextBook t3 = new TextBook("103");
		TextBook t4 = new TextBook("104");
		TextBook t5 = new TextBook("105");
		StoryBook s1 = new StoryBook("Drama");
		StoryBook s2 = new StoryBook("thrillar");
		StoryBook s3 = new StoryBook("romance");
		StoryBook s4 = new StoryBook("comedy");
		StoryBook s5 = new StoryBook("action");
		
		Book b=new Book("102255","Comedy","kazi nazrul",650,152);
		Book b[]= new book[5];
		b[0]=b1;
		b[1]=b2;
		b[2]=b3;
		b[3]=b4;
		b[4]=b5;
		b.setbook(b1);
		b.showDetails();
		b1.setName("Jannatul store");
		System.out.println("bookshop name is :"+b1.getName());
	}
	
}


		

	
