import java.lang.*;
public class dowhileloopdemo
{
	public static void main(String[] args)
	{
		
		int i=2;
		
		do
		{
			System.out.println("Shohan HACKED NASA!");
			i++;
		}
		while(i<=10);
		
	}
	
}

