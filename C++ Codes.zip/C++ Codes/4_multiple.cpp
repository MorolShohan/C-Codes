#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int num1,num2;
    cout<<"Enter two integer : ";
    cin>>num1>>num2;

    if(num1%num2==0){
        cout<<num1<<"is Multiple of"<<num2<<endl;
    }

    else{
        cout<<num1<<"is not a multiple of"<<num2<<endl;
    }










    getch();
}
