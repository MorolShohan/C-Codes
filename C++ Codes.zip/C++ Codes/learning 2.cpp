#include<iostream>
#include<conio.h>
using namespace std;
int main()
{

     char name[13] = "Shohan Morol";

    cout<<"My name is = " <<name;




    getch();
}

