#include<iostream>
using namespace std;
int main ()
{
    float a,b,area;
    cout<<"Enter the Value Of a : ";
    cin>>a;
    cout<<"Enter the value of b : ";
    cin>>b;
    area=(3.1416*a*b);
    cout<<"Area OF Ellipse : "<<area;
    return 0;
}
