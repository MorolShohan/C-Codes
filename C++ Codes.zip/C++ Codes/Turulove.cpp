#include<iostream>
using namespace std;
main ()
{
    cout<<"Omagooo"<<endl;
    cout<<"Turu Love"<<endl;
return 0;
}
