#include<iostream>
using namespace std;\

int main()
{
    string Shohan = "Shohan Afrida";

    cout<<Shohan.substr(7,4);
}
