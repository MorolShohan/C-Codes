#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
   int num;

   cout<<"Enter any input : ";
   cin>>num;

    (num%2==0) ? cout<<num<<" Is even" : cout<<num<<" Is odd";

  getch();
}
