#include<iostream>
using namespace std;

int main()
{

    //switch(option)body
    int option;
    cout<<"Enter an option : ";
    cin>>option;

    switch(option){
case 1:
    cout<<"case 1"<<endl;
    break;
case 2:
    cout<<"case 2"<<endl;
default:
    cout<<"You are in default"<<endl;
    }

}
