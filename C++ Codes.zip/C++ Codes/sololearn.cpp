#include<iostream>
using namespace std;
int main()
{

int num = 1;
int number;

while (num <= 5) {
  cout<<"Enter an integer : ";
  cin >> number;
  num++;
}
}
