#include<iostream>
using namespace std;

int main()
{
  int c,grade;
    char b,course_drop;

    cout<<"Enter your cgpa and grade : ";
    cin>>c>>grade;


    if(cgpa>=3.75 && grade>=b)
    {
        cout<<"You are Applicable for 45% Scholarship ";
    }
    else if{gpa>=3.65 && grade>=b){

         cout<<"You are Applicable for 20% Financial AID";
    }
    else if{gpa>=3.50 && grade>=b){
        cout<<"You are Applicable for 10% Financial AID";
}
    else
    {
        cout<<"You are not Applicable for Scholarship or Financial AID";
    }
}


