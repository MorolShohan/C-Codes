#include<iostream>
using namespace std;
int main ()
{
    float P,T,R,I;
    cout<<"Enter the value of P : ";
    cin>>P;
    cout<<"Enter the value of T : ";
    cin>>T;
    cout<<"Enter the value of R : ";
    cin>>R;
    I=(P*T*R/100);
    cout<<I;
    return 0;
}
