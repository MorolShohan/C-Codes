#include<iostream>
using namespace std;
int main ()
{
    float P=4000,T=2,R=5.5,I;
    I=(P*T*R/100);
    cout<<I;
    return 0;
}
