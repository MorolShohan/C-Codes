#include<iostream>
#include<conio.h>
#include<cstring>
using namespace std;

int main()
{
    char name1[] = "Shohan Morol ";
    char name2[]="Sultan";

    strcat(name1,name2);
    cout<<name1;

}
