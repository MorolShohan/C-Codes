#include<iostream>
using namespace std;
int main ()
{
    float a=4,b=6,area;
    area=(3.1416*a*b);
    cout<<area;
    return 0;
}
