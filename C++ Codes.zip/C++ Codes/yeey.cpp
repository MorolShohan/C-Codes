#include<iostream>
using namespace std;

int main()
{

    cout<<"My name is sazzad"<<endl;
    cout<<" i like benson";

    return 0;

}
