#include<iostream>
using namespace std;
int main ()
{
    float r,area;
    cout<<"Enter The Value Of r : ";
    cin>>r;
    area=(3.1416*r*r);
    cout<<area;
    return 0;
}
