#include<iostream>
#include<conio.h>
using namespace std;
int main ()
{
    int num1,num2,sum;

    cout<<"Enter 2 numbers";
    cin >>num1 >>num2;
    sum = num1 + num2;

    cout<<sum;



    getch();
}
