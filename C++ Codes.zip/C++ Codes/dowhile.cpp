#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int a=5;

    do{cout<<"The num is " <<a<<endl;
    a--;

    }while(a>=1);
}
