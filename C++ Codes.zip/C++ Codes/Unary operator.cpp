#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int x = 3;

   int y = ++x;
    cout<<x<<endl;

    Y = --X;
    cout<<y<<endl;







    getch();
}
