#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int a=32;
    int b=12;
    int c;

    c = a<<3;
    cout<<c<<endl;








    getch();
}

