#include<iostream>
using namespace std;

int main()
{
    int a;

    cout<<a;
}
