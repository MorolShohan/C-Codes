#include<iostream>
using namespace std;

template <class ggez, class ggwp>
ggez add(ggez a ,ggwp b)
{
return a+b;
}

int main()
{
    cout<<"Yasuo best plays  "<<"cancer"<<endl;
    cout<<add(12.3,20)<<endl;
}
