#include<iostream>
using namespace std;

int num1(int);
int num2(int);
int num3(int);
int num4(int);
int avarage;

int main()
{
    int avarage =(num1+num2+num3+num4)/4;
}

int num1(){
    cout<<"enter a number"<<num1;

}
int num2(){
    cout<<"enter a number"<<num2;

}
int num3(){
    cout<<"enter a number"<<num3;

}
int num4(){
    cout<<"enter a number"<<num4;
}
