#include<iostream>
using namespace std;

void display(int a=10, int b=20)
{
  cout<<a<<" "<<b;
}

int main()
{
    display();


}
