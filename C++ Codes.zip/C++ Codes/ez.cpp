#include<iostream>
#include<string>
using namespace std;

int main()
{
    string a,b,c;

    a ="Shohan";
    b =" MOROL ";
    c = a+b;

    cout<<c;
}
