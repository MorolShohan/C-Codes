#include<iostream>
#include<stdlib.h>
#include<conio.h>

using namespace std;

int main(){

        for(int i=1;i>0;i++){
            int  randomnumber = rand();

            cout<<"Random Number"<<randomnumber<<endl;
        }




}
