#include<iostream>
using namespace std;

int main()
{
    int a[]={1,2,3};
    cout<<a[2];
}
