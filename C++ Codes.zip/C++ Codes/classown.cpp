#include<iostream>
#include<conio.h>
using namespace std;

class Student
{
    private :

        string name;
    public :
        void setName(string x)
        {
            name = x;
        }


};

int main()
    {
       student s1;
       s1.name = "Shohan"
       s1.setName("Shohan")

       getch 0;


    }
