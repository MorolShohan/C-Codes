#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    double num1=10.555,num2=20.2365478784547968;
    char ch;
    ch = 'a';

    cout<< "number1=" <<num1<<endl<< "number2=" <<num2<<endl;
    cout<< "character = " << ch;
    getch();
}
