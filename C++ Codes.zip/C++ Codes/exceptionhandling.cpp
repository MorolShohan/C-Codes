#include<iostream>
using namespace std;

int main()
{
    while(1)
    {
       int num1, num2;

    cout<<"Enter ist number : ";
    cin>>num1;

    cout<<"Enter 2nd number : ";
    cin>>num2;

    double result = (double) num1/num2;
    cout<<"Result : "<<result<<endl;
    }


}
