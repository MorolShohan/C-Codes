#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
    char name[30];

    cout<<"ENTER A NAME : ";
    gets(name);

    cout<<"Welcome"<<" "<<name;
}
