#include<iostream>
#include<conio.h>
#include<cstring>
using namespace std;

int main()
{
    char name[]="Shohan";
    strupr(name);
    cout<<name;
}
