#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
cout<< "Happy birthday dst "<<endl;
cout<< "As amra CSEian so vblam evabei wish kori."<<endl;
cout<< "May you get all the happiness in your life. Stay blessed"<<endl;
    getch();
}
