#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    double base,height,area;

    cout<<"Enter base : ";
    cin>>base;

    cout<<"Enter height : ";
    cin>>height;

    area = (double)1/2 * base * height;
    cout<<"The area of triangle = " <<area;








  getch();
}
