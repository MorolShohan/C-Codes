#include<iostream>
using namespace std;
int main()
{
    int marks[5]={55,45,35,25,85};

   int i=0;
   while(i<=4){
     cout<<marks[i]<<" "<<endl;
     i++;
   }



    }






