#include<iostream>
using namespace std;

int sum(int a, int b)
{
    return(a+b);
}
int main()
{
    sum(20,20);
    cout<<sum;
}
