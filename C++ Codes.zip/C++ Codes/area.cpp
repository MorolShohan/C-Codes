#include<iostream>
using namespace std;
int main ()
{
    float r,area;
    r=5;
    area=(3.1416*r*r);
    cout<<area;
    return 0;

}
