#include<iostream>
using namespace std;

int main()
{
    cout<<"Hi babes";
}
