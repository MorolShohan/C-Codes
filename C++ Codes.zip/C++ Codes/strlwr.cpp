#include<iostream>
#include<conio.h>
#include<cstring>
using namespace std;

int main()
{
    char name[]="SHOHAN";
    strlwr(name);
    cout<<name;
}
