#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    double radius,area;
    cout<<"Enter the value of radius : ";
    cin>>radius;

    area = (3.1416 * radius * radius);

    cout<<area;










    getch();
}
